from scapy import *

class IGMP(Packet):
	name = "Internet Group Management Protocol"
	fields_desc = [ ByteField("type", 0),
			ByteField("code", 0),
			ShortField("check", 0)]
# do the rest with RandBin() :)
interact(mydict=globals(), mybanner="IGMP + fuzzing")
