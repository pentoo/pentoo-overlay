from scapy import *

class ISIS(Packet):
	name = "Data Stream Interface"
	fields_desc = [ ByteField("disc", 0),
			ByteField("len", 0),
			ByteField("ver", 0),
			ByteField("idlen", 0),
			ByteField("type", 0),
			ByteField("ver2", 0),
			ShortField("res", 0)]

interact(mydict=globals(), mybanner="ISIS + fuzzing")
