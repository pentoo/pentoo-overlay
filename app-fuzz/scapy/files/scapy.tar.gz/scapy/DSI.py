from scapy import *

class DSI(Packet):
	name = "Data Stream Interface"
	fields_desc = [ ByteField("flag", 0),
			ByteField("command", 0),
			ShortField("id", 0),
			IntField("len", 0),
			IntField("res", 0)]

interact(mydict=globals(), mybanner="DSI + fuzzing")
