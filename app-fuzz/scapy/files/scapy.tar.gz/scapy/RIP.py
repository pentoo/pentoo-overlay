from scapy import *

class RIP(Packet):
	name = "Open Shortest Path First"
	fields_desc = [ ByteField("com", 0),
			ByteField("ver", 0),
			ShortField("dom", 0)]

interact(mydict=globals(), mybanner="OSPF + fuzzing")
