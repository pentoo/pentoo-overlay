from scapy import *

class PTP(Packet):
	name = "PTP"
	fields_desc = [ ShortField("verptp", 0),
			ShortField("vernet", 0),
			StrFixedLenField("sub","%n%n%n%n",16)
			ByteField("type", 0),
			ByteField("blah", 0),
			StrFixedLenField("src","",8),
			ShortField("srcport", 0),
			ShortField("seq", 0),
			ByteField("ctrl", 0),
			ShortField("flag", 0)]
#dst 770, src 320
interact(mydict=globals(), mybanner="PTP + fuzzing")
