from scapy import *

class Zebra(Packet):
	name = "Tacas Protocol"
	fields_desc = [ ByteField("ver", 0x6d),
			ByteField("type", 0),
			ByteField("seq", 0),
			ByteField("flag", 0),
			IntField("id",0),
			IntField("len", 0)]

interact(mydict=globals(), mybanner="Tacas + fuzzing")
