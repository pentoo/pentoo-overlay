from scapy import *

class DCCP(Packet):
	name = "Datagram Congestion Control Protocol"
	fields_desc = [ ShortField("sport", 0),
			ShortField("dport", 0),
			ByteField("off", 0),
			ByteField("cval",0),
			ShortField("check",0),
			ByteField("type", 0),
			StrFixedLenField("seq","",3),
			StrFixedLenField("ack","",3)]
# do the rest with RandBin() :)
interact(mydict=globals(), mybanner="DCCP + fuzzing")
