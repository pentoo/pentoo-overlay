from scapy import *

class OSPF(Packet):
	name = "Open Shortest Path First"
	fields_desc = [ ByteField("ver", 0),
			ByteField("type", 0),
			ShortField("len", 0),
			IntField("src", 0),
			IntField("id", 0),
			ShortField("check", 0)]

interact(mydict=globals(), mybanner="OSPF + fuzzing")
