from scapy import *

class EIGRP(Packet):
	name = "Data Stream Interface"
	fields_desc = [ ByteField("ver", 0),
			ByteField("op", 0),
			ShortField("check", 0),
			IntField("flag", 0),
			IntField("seq", 0),
			IntField("ack", 0),
			IntField("auto", 0),
			ShortField("type", 0),
			ShortField("size", 0) ]

interact(mydict=globals(), mybanner="EIGRP + fuzzing")
