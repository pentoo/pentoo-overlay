from scapy import *

class RPC(Packet):
	name = "Data Stream Interface"
	fields_desc = [ IntField("xid", 0),
			IntField("call", 0),
			IntField("ver", 0),
			IntField("prognr", 0),
			IntField("vernr",0),
			IntField("procnr", 0)]

class RPC_cred(Packet):
	name = "RPC credentials"
	fields_desc = [ IntField("Flavor", 0),
			IntField("len", 0)]

class RPC_ver(Packet):
        name = "RPC verifier"
        fields_desc = [ IntField("Flavor", 0),
                        IntField("len", 0)]

class RPC_bootparam_getfile(Packet):
	name = "bootparam getfile"
	fields_desc = [ IntField("len", 0)]
# after that is an arbitrary file name

interact(mydict=globals(), mybanner="RPC + fuzzing")
