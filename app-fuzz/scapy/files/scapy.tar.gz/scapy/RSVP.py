from scapy import *

class RSVP(Packet):
	name = "Resource ReserVation Protocol"
	fields_desc = [ ByteField("ver", 0),
			ByteField("type", 0),
			ShortField("check", 0),
			ByteField("ttl",0),
			ByteField("unused", 0),
			ShortField("len", 0),
			ShortField("objlen", 0),
			ByteField("Class",0),
			ByteField("ctype",0)]

interact(mydict=globals(), mybanner="RSVP + fuzzing")
