from scapy import *

class VIP(Packet):
	name = "Banyan Vines IP"
	fields_desc = [ ByteField("flag", 0),
			ByteField("seq", 0),
			ShortField("check",0),
			ShortField("len", 0),
			ByteField("ctrl", 0),
			ByteField("proto", 0),
			StrFixedLenField("dst","",6),
			StrFixedLenField("src","",6)]
# do the rest with RandBin() :)
interact(mydict=globals(), mybanner="VIP + fuzzing")
